function load() {
    fetch(API + "/entries")
    .then(res => res.json())
    .then(data => {

        const table = document.getElementById("data");
        const tinEl = document.getElementById("tin");
        const toutEl = document.getElementById("tout");

        if (!table) return;

        table.innerHTML = "";

        let tin = 0;
        let tout = 0;

        data.forEach(item => {
            tin += Number(item.cashIn || 0);
            tout += Number(item.cashOut || 0);

            table.innerHTML += `
                <tr>
                    <td>${item.date || ""}</td>
                    <td>${item.time || ""}</td>
                    <td>${item.cashIn || 0}</td>
                    <td>${item.cashOut || 0}</td>
                </tr>
            `;
        });

        if (tinEl) tinEl.innerText = tin;
        if (toutEl) toutEl.innerText = tout;

    })
    .catch(err => console.log("Load error:", err));
}