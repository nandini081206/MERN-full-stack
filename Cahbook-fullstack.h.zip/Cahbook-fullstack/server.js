const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

let entries = [];

/* LOGIN */
app.post("/login", (req, res) => {
const { username, password } = req.body;

```
console.log("Login:", username, password);

if (username === "admin" && password === "1234") {
    res.json({ success: true });
} else {
    res.json({ success: false });
}
```

});

/* ADD ENTRY */
app.post("/add", (req, res) => {
entries.push(req.body);
res.json({ message: "added" });
});

/* GET ENTRIES */
app.get("/entries", (req, res) => {
res.json(entries);
});

app.listen(PORT, () => {
console.log("Server running on http://localhost:3000");
});
